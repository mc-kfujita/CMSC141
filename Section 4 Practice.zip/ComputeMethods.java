import java.util.Random;

public class ComputeMethods {
	
	public double fToC(double degreeF) {
		double degreeC= (degreeF-32) * 5/9;
		return degreeC;
	}
	
	public void displayTest1() {
		double degreeF= 100.0;
		double degreeC= fToC(degreeF);
		double roundOff= (double) Math.round(degreeC);
		System.out.println(degreeF+ " Fahrenheit is "+ roundOff+" in Celsius.");
	}
	
	public double hypotenuse(int h, int l) {
		double height= h*h;
		double length= l*l;
		double hypo= Math.sqrt(height)* Math.sqrt(length);
		return hypo;
	}
	
	public int roll() {
		Random rand= new Random();
		return rand.nextInt(6)+ 1+ rand.nextInt(6)+ 1+ rand.nextInt(6)+ 1+ rand.nextInt(6)+ 1+ rand.nextInt(6)+ 1+ rand.nextInt(6)+ 1;
	}
	
}