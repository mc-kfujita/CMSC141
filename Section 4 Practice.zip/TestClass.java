
public class TestClass {
	public static void main(String[] args) {
		
		ComputeMethods computeMethods= new ComputeMethods();
		System.out.println("The converted Celsius is "+ computeMethods.fToC(90.0)+ ".");
		System.out.println("The hypotenuse is "+ computeMethods.hypotenuse(5, 4)+ ".");
		System.out.println("The sum of dice rolled 6 times is "+ computeMethods.roll()+ ".");
		
		}
	
}