import java.util.Scanner;


public class ProcessName {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		System.out.print("Enter your name: ");
		String name= input.nextLine();
		
		String[] fullName = name.split(" ");
		
		int i= fullName.length;
		String firstName= fullName[0]; 
		String lastName= fullName[i-1];
		char displayFirstChar= firstName.charAt(0);
		
		System.out.println("Your name is "+lastName+ ", "+displayFirstChar+ ".");
	}

}