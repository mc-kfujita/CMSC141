public class Parsing01 {
    public static void main(String[] args) {
        //Declare and intitialize 3 Strings: shirtPrice, taxRate, and gibberish
        String shirtPrice= "15";
        String taxRate= "0.05";
        String gibberish= "887ds7nds87dsfs";
        
        
        //Parse shirtPrice and taxRate, and print the total tax
        int intPar1= Integer.parseInt(shirtPrice);
        double doublePar1= Double.parseDouble(taxRate);
        
        double tax= intPar1* doublePar1;
        
        System.out.println(tax);
        
        //Try to parse taxRate as an int
        int intPar2= Integer.parseInt(taxRate); //observed
        
        //Try to parse gibberish as an int
        int intPar3= Integer.parseInt(gibberish); //observed
        
    }
    
}
