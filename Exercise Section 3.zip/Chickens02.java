public class Chickens02 {
    public static void main(String[] args) {
        // Implementing attributes and set the values for the scenario.
    	double monEggs= 100;
    	double tueEggs= 121;
    	double wedEggs= 117;
    	
    	// Implementing calculation for the required info.
    	double avgDaily= (monEggs+ tueEggs+ wedEggs)/3;
    	double avgMonthly= avgDaily*30;
    	double profit= avgMonthly* 0.18;
    	
    	// Outputting the daily average amount of eggs collected, monthly 
    	// average of eggs collected, and the monthly profit for selling eggs for 18 cents each.
        System.out.println("Daily Average: "+ avgDaily);
        System.out.println("Monthly Average: "+ avgMonthly);
        System.out.println("Profit: $"+ profit);

    }   
}
