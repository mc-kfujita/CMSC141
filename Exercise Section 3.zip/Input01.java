import javax.swing.JOptionPane;

public class Input01 {
    public static void main(String[] args) {
        //Create a JOptionPane.
//    	JOptionPane.showInputDialog("Type something: ");
        
    	//Store the input as a String and print it.
    	String input= JOptionPane.showInputDialog("Type numbers without decimals: ");
    	System.out.println(input);
        
        
        //Parse the input as an int
    	int intPar= Integer.parseInt(input);
    	
        //Print its value +1
    	intPar++;
    	
    	System.out.println(intPar);
        
        
        //Try creating a dialog, parsing it, and initializing an int in a single line.
        //You should have only one semicolon (;) in this line.

        
    }
}
