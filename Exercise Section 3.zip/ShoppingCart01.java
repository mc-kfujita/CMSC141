public class ShoppingCart01 {
    public static void main(String[] args) {
        // Declare and initialize String variables.  Do not initialize message yet.
        String custName, itemDesc;
        
        
        // Assign the message variable 
        custName= "Alex";
        itemDesc= "Shirt";
        
        
        
        // Print and run the code
        System.out.println(custName+ " wants to purchase a "+ itemDesc);
        
    }
}
