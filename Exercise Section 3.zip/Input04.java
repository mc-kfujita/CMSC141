import java.util.Scanner;

public class Input04 {
    public static void main(String[] args){
        Scanner sc = new Scanner(Input04.class.getResourceAsStream("Level05.txt"));      
        
        //Edit these lines to advance the scanner
        System.out.println(sc.nextLine());
        System.out.println(sc.nextLine());
        System.out.println(sc.nextLine());
        
        sc.nextLine();
        
        //Does this line contain "BlueBumper"?
        System.out.println(sc.findInLine("BlueBumper"));
        
        //Store the next two numbers as xPosition and yPosition
        //Print these positions
        String xy= sc.nextLine();
        int xPosition= 0;
        int yPosition= 0;
        
        Scanner lineScanner= new Scanner(xy);
        
        for(int i=0; i<3; i++) {
                
        	if(xy.contains("120"))
        		xPosition= 120;        
        	if(xy.contains("450"))
        		yPosition= 450;
        }
        
        System.out.println("X: "+ xPosition+", Y: "+ yPosition);
        
        sc.close();
    }    
}
