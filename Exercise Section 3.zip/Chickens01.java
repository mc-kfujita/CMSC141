public class Chickens01 {
    public static void main(String[] args) {
        // Implementing attributes and set the values to them for the first scenario.
    	int eggsPerChicken= 5;
    	int chickenCount= 3;
    	
    	// Implementing calculation for the 1st scenario and output it.
    	int mon= chickenCount* eggsPerChicken;
    	chickenCount++;
    	int tue= chickenCount* eggsPerChicken;
    	int wed= (chickenCount/2)* eggsPerChicken;
    	int totalEggs= mon+ tue+ wed;
    	
        System.out.println(totalEggs+ " First scenario");
    	
        // Set the values of attributes again for the 2nd scenario, redo the calculation, and output it.
    	eggsPerChicken= 4;
    	chickenCount= 8;
    	
    	mon= chickenCount* eggsPerChicken;
    	chickenCount++;
    	tue= (chickenCount)* eggsPerChicken;
    	wed= (chickenCount/2)* eggsPerChicken;
    	totalEggs= mon+ tue+ wed;
        
        System.out.println(totalEggs+ " Second scenario");
    }   
}
