import java.util.Scanner;

class Input03 {

    public static void main(String[] args) {
        //Create a Scanner
    	Scanner input= new Scanner(System.in);
    	System.out.println("Enter numbers 3 times: \n");
    	
    	
        //Find and print the sum of three integers entered by the user
        int x= input.nextInt();
        int y= input.nextInt();
        int z= input.nextInt();
        
        int sum= x+ y+ z;
        
    	System.out.println("\nSum of your numbers: "+ sum);
        
        //Remember to close the Scanner
        input.close();
    }
}
