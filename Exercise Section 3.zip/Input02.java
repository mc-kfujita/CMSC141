import javax.swing.JOptionPane;

public class Input02 {
    public static void main(String[] args) {
        
        JOptionPane.showMessageDialog(null,
                "This is multiplication calculator.",
                "Exercise 2: Info",
                0);

        
        String input1 = (String)JOptionPane.showInputDialog(null,
                "Please do not put anything except for a number.",
                "Exercise 2: Input",
                2,
                null,
                null,
                "Type your number here.");
        
        
        String[] acceptableValues = {"Multiply by 2", "Multiply by 3", "Multiply by 4"};
        acceptableValues[0]= "2";
        acceptableValues[1]= "3";
        acceptableValues[2]= "4";
        
        String input2 = (String)JOptionPane.showInputDialog(null,
                "Choose your multiplication.",
                "Exercise 2: Choice",
                2,
                null,
                acceptableValues,
                acceptableValues[1]);
        
        int intPar= Integer.parseInt(input1);
        int intChoice= Integer.parseInt(input2);
        int mul= intPar* intChoice;
        System.out.println("The answer is: "+ mul);
    
    }
}
