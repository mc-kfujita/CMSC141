
public class AccountTest {
	public static void main(String[] args) {
		
		CheckingAccount ca0001= new CheckingAccount();
		
		ca0001.balance= 1000.00;
		ca0001.name= "Katsumi";
		
		ca0001.withdraw(500.00);
		
		System.out.println();
		
		SavingBond sb0001= new SavingBond();
		
		sb0001.balance= 1000.00;
		sb0001.name= "Katsumi";
		
		sb0001.setTermAndInterest(60);
		sb0001.earnInterest();
		
	}

}
