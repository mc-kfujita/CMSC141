//Section 7, Lesson 5 Starter for Exercise 1 - Slide 10

public class Prisoner_Student_7_5 {
    //Fields 
    private String name;
    private double height;
    private int sentence;
    private Cell cell;
    
    //Constructor
    
    public Prisoner_Student_7_5(String name, double height, int sentence, Cell cell){
 	this.name = name;
 	this.height = height;
 	this.sentence = sentence;
 	this.cell= cell;
    }
    
    //Methods
    public void think(){
        System.out.println("I'll have my revenge.");
    }
    
    public void display(){
        System.out.println(cell.getName());
        
    }

    public Cell getCell() {
    	return cell;
    }

    public void setCell(Cell cell) {
    	this.cell = cell;
    }

    public String getName() {
    	return name;
    	
    }
    
    public void setName(String n) {
    	name = n;
    	
    }

    public double getHeight() {
    	return height;
    }

    public void setHeight(double h) {
    	height = h;
    }

    public int getSentence() {
    	return sentence;
    }

    public void setSentence(int s) {
    	sentence = s;
    }

    public void setFields(String n, double h, int s) {
    	name = n;
    	height = h;
    	sentence = s;
    	
    }
    
    public void displayPrisoner() {
    	System.out.println(this.name+ " "+ this.height+ " "+ this.sentence);
    }
    
    public void displayPrisoner(boolean flag) {
    	
    	if (flag == true) {
    		think();
    	}
    	
    	else {
    		System.out.println("Prisoner Details : " + this.name + " " + this.height + " " + this.sentence);
    	}
    	
    }    
    
}
