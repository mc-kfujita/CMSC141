
public class Prisoner {
	public double height;
	public int sentence;
	public String name;
	
	public Prisoner(String name, double height, int sentence) {
		this.name= name;
		this.height= height;
		this.sentence= sentence;
	}

}
