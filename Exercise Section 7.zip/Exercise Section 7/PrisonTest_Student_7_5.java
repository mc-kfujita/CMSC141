//Section 7, Lesson 5 Starter for Exercise 1 - Slide 10

public class PrisonTest_Student_7_5 {
    public static void main(String[] args){
        
    	Cell cell = new Cell("No.141", true, 1001);
    	Prisoner_Student_7_5 p01 = new Prisoner_Student_7_5("Bubba", 6.10, 4, cell);
    	
    	p01.display();
    	p01.displayPrisoner();

    	cell.setIsOpen(1000);
    	cell.setIsOpen(1000);
    	cell.setIsOpen(1000);
    	cell.setIsOpen(1001);

    	}
}
