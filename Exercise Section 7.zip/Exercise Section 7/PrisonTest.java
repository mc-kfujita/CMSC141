
public class PrisonTest {
	public static void main(String[] args) {
		Prisoner bubba= new Prisoner("Bubba", 6.10, 4);
		Prisoner twitch= new Prisoner("twitch", 5.8, 3);
		
//		bubba=twitch;
		
		System.out.println(bubba == twitch);
		
		String s1= new String ("bubba");
		String s2= new String ("bubba");
		
		System.out.println(s1 == s2);
		
		s1= "bubba";
		s2= "bubba";
		
		System.out.println(s1 == s2);
		
		Prisoner_Student_7_3 p01= new Prisoner_Student_7_3();
		System.out.println("\n"+ p01.name+ "\n"+ p01.height+ "\n"+p01.sentence);
		
		Prisoner_Student_7_3 p02= new Prisoner_Student_7_3();
		
		p01.setPrisoner("Bubba", 6.10, 4);
		p02.setPrisoner("Twitch", 5.8, 3);
		

		System.out.println("\n"+ bubba.name+ "\n"+ bubba.height+ "\n"+bubba.sentence);
		System.out.println("\n"+ twitch.name+ "\n"+ twitch.height+ "\n"+twitch.sentence);


	}
	
}
