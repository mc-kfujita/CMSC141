//Section 7, Lesson 3 Starter for Exercise 1 - Slide 6

public class PrisonTest_Student_7_3 {

    public static void main(String[] args) {
    	Prisoner_Student_7_3 p01= new Prisoner_Student_7_3();
    	Prisoner_Student_7_3 p02= new Prisoner_Student_7_3();

    	p01.display();
    	p02.display("Bubba", 6.10, 4);
    	
    	Prisoner_Student_7_3 p03= new Prisoner_Student_7_3("Twitch", 5.8, 3);
    	p03.display();


    } 
}
