
public class Cell {
	private String name, cell;
	private boolean isOpen;
	private int code;
	
	public Cell(String name, boolean isOpen, int code) {
		this.name= name;
		this.isOpen= isOpen;
		this.code= code;
	}
	
	public String getName() {
		return name;
	}

	public boolean getIsOpen() {
		return isOpen;
	}
	
	public void setIsOpen(int security) {
		if(security != code) {
			System.out.println("Incorrect.");
		}
		
		else {
			if(isOpen == true) {
				isOpen= false;
				System.out.println("Cell "+ name+ " closed.");
			}
			
			else {
				isOpen= true;
				System.out.println("Cell "+ name+ " Opened.");
			}
			
		}
	}
}
