//Section 7, Lesson 3 Starter for Exercise 1 - Slide 6

public class Prisoner_Student_7_3 {

    //Fields 
    public String name;
    public double height;
    public int sentence;
    public boolean stat= false;
    
    //Constructor
    Prisoner_Student_7_3(){
    }
    
    Prisoner_Student_7_3(String name, double height, int sentence){
    	this.name= name;
    	this.height= height;
    	this.sentence= sentence;
    }

    
    //Methods
    public void think(){
        System.out.println("I'll have my revenge.");
    }
    
    public void display() {
    	System.out.println(name+ " "+height+ " "+ sentence);
    }
    
    public void display(String name, double height, int sentence) {
    	boolean stat= false;
    	System.out.println(name+ " "+height+ " "+ sentence);
    	if(true) {
    		think();
    	}
    }
    
}