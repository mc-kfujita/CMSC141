//Section 7, Lesson 6 Starter for Exercise 2 - Slide 16

public class PrisonTest_Student_7_6 {
    public static void main(String[] args){
        Cell_Student_7_6 cellA1 = new Cell_Student_7_6("A1", false, 1234);
        Cell_Student_7_6 cellB1 = new Cell_Student_7_6("B1", false, 1234);
        Cell_Student_7_6 cellC1 = new Cell_Student_7_6("C1", false, 1234);
        Cell_Student_7_6 cellD1 = new Cell_Student_7_6("D1", false, 1234);
        
        Prisoner_Student_7_6 bubba = new Prisoner_Student_7_6("Bubba", 6.10, 4, cellA1);
        Prisoner_Student_7_6 twitch = new Prisoner_Student_7_6("Twitch", 5.8, 3, cellB1);

        
        bubba.display();
        System.out.println();
        twitch.display();

    }
}
