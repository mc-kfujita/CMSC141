
public class CheckingAccount {
	public double balance;
	public String name;
	
	public void withdraw(double x) {
		if(x>1000) {
			System.out.println("The balance is too low.");
		}
		
		else if(x<0) {
			System.out.println("The withdraw amount cannot be negative number.");
		}
		
		else {
			balance -=x;
			System.out.println("Your new balance: $"+ balance);
		}
		
	}

}
