
public class PrizeCategories {
	private String name;
	private int ticketReq, count;
	
	public PrizeCategories(String name, int ticketReq, int count) {
		this.name= name;
		this.ticketReq= ticketReq;
		this.count= count;
	}
	
	public String getName() {
		return name;
	}
	
	public int getTicketReq() {
		return ticketReq;
	}
	
	public int getCount() {
		return count;
	}
	
	public void minusPrize() {
		count--;
	}
	
}
