
public class Terminals {
	
	public static void main(String[] args) {
        Cards card1= new Cards(1, 20);
        Cards card2= new Cards(2, 30);
        
        Games game1= new Games(1);
        PrizeCategories teddyBear= new PrizeCategories("teddy bear", 10, 1);
        
        System.out.println("Card 1 obtained. Credit remaining: "+ card1.getCredit());
        System.out.println("Card 2 obtained. Credit remaining: "+ card2.getCredit());
        
        card1.playGame(game1);
        System.out.println("Game played with Card 1");
        System.out.println("Ticket balance in Card 1: "+card1.getTicket());
        
        card1.playGame(game1);
        System.out.println("Game played with Card 1");
        System.out.println("Ticket balance in Card 1: "+card1.getTicket());
        
        card1.playGame(game1);
        System.out.println("Game played with Card 1");
        System.out.println("Ticket balance in Card 1: "+card1.getTicket());

        card1.playGame(game1);
        System.out.println("Game played with Card 1");
        System.out.println("Ticket balance in Card 1: "+card1.getTicket());
        
        System.out.println("Card 1 credit remaining: "+ card1.getCredit());
        System.out.println("Card 2 credit remaining: "+ card2.getCredit());
        
        card1.transferCredit(card2, 10);
        System.out.println("Card 1 credit remaining: "+ card1.getCredit());
        System.out.println("Card 2 credit remaining: "+ card2.getCredit());
        
        System.out.println("Used Card 2 to redeem prize");
        card2.redeemPrize(teddyBear);
        
        System.out.println("Used Card 1 to redeem prize");

        card1.redeemPrize(teddyBear);
        
        card1.transferTicket(card2, 10);
        card2.redeemPrize(teddyBear);
        
        card2.playGame(game1);
        System.out.println("Game played with Card 2");
        System.out.println("Ticket balance in Card 2: "+card2.getTicket());
        
        System.out.println("Used Card 2 to redeem prize");
        card2.redeemPrize(teddyBear);
        
        card1.transferCredit(card2, 6);
        System.out.println("Card 1 credit remaining: "+ card1.getCredit());
        System.out.println("Card 2 credit remaining: "+ card2.getCredit());
        
        card1.playGame(game1);
        System.out.println("Game played with Card 1");
        System.out.println("Ticket balance in Card 1: "+card1.getTicket());
	}
}