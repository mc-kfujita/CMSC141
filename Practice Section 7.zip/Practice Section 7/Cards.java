
public class Cards {
	private int cardNum, credit, ticket;
	
	public Cards(int cardNum, int credit) {
		this.cardNum= cardNum;
		this.credit= credit;
		this.ticket= 0;
	}
	
	public int getCardNum() {
		return cardNum;
	}
	
	public int getCredit() {
		return credit;
	}
	
	public int getTicket() {
		return ticket;
	}
	
	public void setCredit(int credit) {
		this.credit= credit;
	}
	
	public void setTicket(int ticket) {
		this.ticket= ticket;
	}
	
	public void playGame(Games game) {
		if(credit >= game.getCreditReq()) {
			credit -= game.getCreditReq();
			ticket += game.randomTicket();
		}
		
		else {
			System.out.println("Not enough credit to play the game.");
		}
		
	}
	
	public void transferCredit(Cards other, int x) {
		if(credit >= x) {
			credit -=x;
			other.setCredit(other.getCredit()+ x);
			System.out.println(x+ " credits transferred from the card "+ cardNum+ " to the card "+ other.getCardNum());
		}
		
		else {
			System.out.println("Not enough credit to transfer.");
		}
		
	}
	
	public void transferTicket(Cards other, int x) {
		if(ticket >= x) {
			ticket -= x;
			other.setTicket(other.getTicket()+ x);
			System.out.println(x+ " tickets transferred from Card "+ cardNum+ " to Card "+ other.getCardNum());
		}
		
		else {
			System.out.println("Not enough ticket to transfer.");
		}
	}
	
	public void redeemPrize(PrizeCategories prizeCategory) {
		if(ticket >= prizeCategory.getTicketReq()) {
			ticket -= prizeCategory.getTicketReq();
			prizeCategory.minusPrize();
			System.out.println("Redeemed prize "+ prizeCategory.getName()+ " from Card "+ cardNum);
		}
		
		else {
			System.out.println("Not enought ticket to redeem prize.");
		}

	}

}
