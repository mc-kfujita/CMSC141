
public class Games {
	private int creditReq;
	
	public Games(int creditReq) {
		this.creditReq= creditReq;
	}
	
	public int getCreditReq() {
		return creditReq;
	}
	
	public int randomTicket() {
		int ticket= (int) (Math.random()* 10);
		return ticket;
	}

}
