import java.util.Scanner;

public class TrafficLightSwitch {

    public static void main(String args[]) {
    	
    	System.out.print("Enter a color code in number between 1 and 3: \n");
    	Scanner input= new Scanner(System.in);
    	int currentColor= input.nextInt();
    	
    	switch(currentColor) {
    	
    	case 1:
        	System.out.println("Next Traffic Light is green.");
        	break;
        	
    	case 2:
        	System.out.println("Next Traffic Light is yellow.");
        	break;
        	
    	case 3:
        	System.out.println("Next Traffic Light is red.");
        	break;
        	
        default:
    		System.out.println("Invalid color");
    	}
    	
    }
}
