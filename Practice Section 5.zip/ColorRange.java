import java.util.Scanner;

public class ColorRange {

    public static void main(String args[]) {
    	
    	System.out.print("Enter a wavelength(nm) of color: \n");
        Scanner input= new Scanner(System.in);
        double nm= input.nextDouble();
        
        if(nm>= 380 && nm< 450) {
        	System.out.println("The color is violet.");
        }
        
        else if(nm>= 450 && nm< 495) {
        	System.out.println("The color is blue.");
        }
        
        else if(nm>= 495 && nm< 570) {
        	System.out.println("The color is green.");
        }
        
        else if(nm>= 570 && nm< 590) {
        	System.out.println("The color is yellow.");
        }
    	
        else if(nm>= 590 && nm< 620) {
        	System.out.println("The color is orange.");
        }
        
        else if(nm>= 620 && nm< 750) {
        	System.out.println("The color is red.");
        }
        
        else {
            System.out.println("The wavelength you entered is not a visible color.");
        }

    }
}