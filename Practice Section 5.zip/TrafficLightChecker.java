import java.util.Scanner;

public class TrafficLightChecker {

    public static void main(String args[]) {
    	
    	System.out.print("Enter a color code in number between 1 and 3: \n");
    	Scanner input= new Scanner(System.in);
    	int currentColor= input.nextInt();
    	
    	if(currentColor == 1) {
        	System.out.println("Next Traffic Light is green.");
    	}
    	
    	else if(currentColor == 2) {
        	System.out.println("Next Traffic Light is yellow.");
    	}
    	
    	else if(currentColor == 3) {
        	System.out.println("Next Traffic Light is red.");
    	}
    	
    	else {
    		System.out.println("Invalid color");
        }
    	
    }
}
