public class LoopShape {
    
    static void createRectangle(int width, int height){
        //Draw a Rectangle
        if(width<1 || height<1) {
        	System.out.println("Invalid input.");
        }
        
        for(int i=0; i<width; i++) {
        		System.out.print("#");
        	}
        
		System.out.println();

        for(int j=0; j<height-2; j++) {
    		System.out.print("#");
        	for(int k=0; k<width-2; k++) {
        		System.out.print(" ");
        	}
        	
    		System.out.println("#");

        }
        
        for(int l=0; l<width; l++) {
    		System.out.print("#");
    	}
        
		System.out.println();
        
    }
    
    static void createTriangle(int leg){
        //Draw an Isosceles Right Triangle
    	
    	for (int i=0; i<=leg; i++) {
    		
    		for (int j=0; j<=i-1; j++) {
    			
    			if (i == leg) {
    				
    				for (int k=0; k<=leg-1; k++)
    					System.out.print("#");
    					break;
    			}
    			
    			else if (i>1) {
    				System.out.print("#");
    				for (int l=0; l<i-1; l++)
    					System.out.print(" ");
    					System.out.print("#");
    					break;
    			}
    			
    			else {
    				System.out.print("#");
    			}
    		}
    		
    		System.out.println();
    		
    	}
    	
    	System.out.println();
    	System.out.println();
    	
    }
    
}