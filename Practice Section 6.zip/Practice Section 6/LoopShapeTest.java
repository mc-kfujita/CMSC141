public class LoopShapeTest {
    public static void main(String[] args) {
        
        LoopShape.createRectangle(10, 8);
        System.out.println();
        LoopShape.createTriangle(10);
    }   
}
