import java.util.Scanner;

public class ValidatePin {

    public static void main(String[] args) {
        int validPin= 9117;
        
        System.out.print("Enter 4 digits of your PIN: ");
        Scanner input= new Scanner(System.in);
        int pin= input.nextInt();
        
        while(pin != validPin) {
        	System.out.print("\nThe PIN you entered is incorrect. \nPlease try again: ");
            pin= input.nextInt();
        }
        
    	System.out.print("\nPIN is correct. You now have access to your account.");
        
    }
}
