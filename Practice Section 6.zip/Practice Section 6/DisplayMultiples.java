import java.util.Scanner;

public class DisplayMultiples {

    public static void main(String args[]) {
    	
        System.out.print("Choose a number: ");
        Scanner input= new Scanner(System.in);
        int num= input.nextInt();
        
        System.out.println();
        
        for(int i=1; i<13; i++) {
            System.out.println("7x"+i +" = "+ 7*i);
        }
        
    }

}
