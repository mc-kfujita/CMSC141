import javax.swing.JOptionPane;

public class problemSet03 {
	public static void main(String[] args) {
		// Attributes.
		String name;
		String occupation;
		String city;
		String state;
		String phoneNum;
		int zip;
		int age;
		int momAge;
		double height;
		double weight;
		
		// Asking user to input 10 questions.
		name= (JOptionPane.showInputDialog("Question 1 of 10", "Enter your name: "));
		occupation= (JOptionPane.showInputDialog("Question 2 of 10", "Enter your occupation: "));
		phoneNum= (JOptionPane.showInputDialog("Question 3 of 10", "Enter your phone number: "));
		city= (JOptionPane.showInputDialog("Question 4 of 10", "Enter the city you live: "));
		state= (JOptionPane.showInputDialog("Question 5 of 10", "Enter the state you live: "));
		zip= Integer.parseInt(JOptionPane.showInputDialog("Question 6 of 10", "Enter your zip: "));
		age= Integer.parseInt(JOptionPane.showInputDialog("Question 7 of 10", "Enter your age: "));
		momAge= Integer.parseInt(JOptionPane.showInputDialog("Question 8 of 10", "Enter your mother's age: "));
		height= Double.parseDouble(JOptionPane.showInputDialog("Question 9 of 10", "Enter your height in lbs: "));
		weight= Double.parseDouble(JOptionPane.showInputDialog("Question 10 of 10", "Enter your weight in ft: "));
		
		// Doing math based on the user input.
		int ageDif= momAge- age;
		double ftToCm= height* 30.48;
		double lbsToKg= weight/ 2.205;
		
		// Showing output
		JOptionPane.showMessageDialog(null, "Your name: "+ name+ "\nYour occupation: "+ occupation+ "\nYour phone number: "+ phoneNum+
									  "\nYour city: "+ city+ "\nYour state: "+ state+ "\nYour zip: "+ zip+
									  "\nYour age: "+ age+ "\nYour mother's age: "+ momAge+ "\nThe age difference between you and your mother: "+ ageDif+
									  "\nYour height (ft/cm): "+ height+ "/ "+ ftToCm+ "\nYour weight (lbs/kg): "+ weight+ "/ "+ lbsToKg);
		
	}

}
