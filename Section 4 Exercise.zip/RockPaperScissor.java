import java.util.Random;
import java.util.Scanner;

public class RockPaperScissor {

    public static void main(String[] args) {
        
        while(true) {	
            Scanner input= new Scanner(System.in);
            Random rand = new Random();
            int chance = rand.nextInt(3);
            
            switch(chance) {
        		case 0:
        			System.out.println("Rock");
        			break;
        	
        		case 1:
        			System.out.println("Paper");
        			break;
        	
        		case 2:
        			System.out.println("Scissors");
        			break;
        			
            }
            
            System.out.println("\nContinue?(Y/N)");
            String answer= input.nextLine();
            
            if(answer.equalsIgnoreCase("n"))
            	break;
            
        }
        
        System.out.println("Good bye.");         		
    		
    }    

}
