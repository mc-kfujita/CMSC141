public class Tip01 {
    public static void main(String[] args) {
        //Find everyone's indivudlal total after tax(5%) and tip(15%)
    	double tax= 0.05;
    	double tip= 0.15;
        
        /*This is what everyone owes before tax and tip:
        Person 1: $10
        Person 2: $12
        Person 3: $9
        Person 4: $8
        Person 5: $7
        Person 6: $15
        Person 7: $11
        Person 8: $30
        */
    	
    	int person1= 10;
    	int person2= 12;
    	int person3= 9;
    	int person4= 8;
    	int person5= 7;
    	int person6= 15;
    	int person7= 11;
    	int person8= 30;
    	
    	double total1= person1+ (person1* tax)+ (person1* tip);
    	double total2= person2+ (person2* tax)+ (person2* tip);
    	double total3= person3+ (person3* tax)+ (person3* tip);
    	double total4= person4+ (person4* tax)+ (person4* tip);
    	double total5= person5+ (person5* tax)+ (person5* tip);
    	double total6= person6+ (person6* tax)+ (person6* tip);
    	double total7= person7+ (person7* tax)+ (person7* tip);
    	double total8= person8+ (person8* tax)+ (person8* tip);
    	
    	System.out.println("person1: $"+ total1);
    	System.out.println("person2: $"+ total2);
    	System.out.println("person3: $"+ total3);
    	System.out.println("person4: $"+ total4);
    	System.out.println("person5: $"+ total5);
    	System.out.println("person6: $"+ total6);
    	System.out.println("person7: $"+ total7);
    	System.out.println("person8: $"+ total8);
        
    }    
}
