import java.util.Scanner;


public class ComputeBMI {
    public static void main(String[] args) {
    	double weight, height, bmi;
    	
    	Scanner input= new Scanner(System.in);
    	
    	System.out.println("Enter your weight in kilograms: ");
    	weight= input.nextDouble();
    	
    	System.out.println("Enter your height in centimeters: ");
    	height= input.nextDouble();
    	
    	bmi= (weight)/((height/ 100)* (height/ 100));
    	int roundOff= (int) Math.round(bmi);
        
        System.out.println("Your Body Mass Index is " + roundOff);
        }
}
