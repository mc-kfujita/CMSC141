import java.util.Random;
import java.util.Scanner;

public class FlipCoin {

    public static void main(String[] args) {
    	
            while(true) {	
                Scanner input= new Scanner(System.in);
            	
            	// 50% chance heads, 50% chance tails
            	Random rand = new Random();
            	double chance = rand.nextDouble();
            	System.out.println(chance);
    		
            	if(chance<0.5)
            		System.out.println("Heads");
            	else
            		System.out.println("Tails");
            	
            	System.out.println("\nContinue?(Y/N)");
            	String answer= input.nextLine();
            	
            	if(answer.equalsIgnoreCase("n"))
            		break;
            	}
            
            System.out.println("Good bye.");         		
            
    }
}