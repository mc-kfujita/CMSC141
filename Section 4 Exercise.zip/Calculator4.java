
public class Calculator4 {
    public double tax = .05;
    public double tip = .15;
    double total= 0;
	double sum= 0;
	double quotient= 0;    
	
	public void findTotal(String name, double price){
		total= price*(1+tax+tip);
		sum += total;
		}
	
    public double calculate(double sum, int num){
    	quotient= sum/num;
		return quotient;
		}
    
    //To test if methods work property.
    public void display() {
    	System.out.println("Total Cost: $"+ sum+ "\nEach Cost Excluding Alex and Person 8: $"+ quotient);
    	}
    
}