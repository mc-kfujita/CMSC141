import java.util.Scanner;

public class NameMaker {
    
    public static void main(String args[])
    {
        String firstName, middleName, lastName, fullName;
        
        Scanner input= new Scanner(System.in);
        
        System.out.print("Enter your first name: ");
        firstName= input.nextLine();
        
        System.out.print("Enter your middle name: ");
        middleName= input.nextLine();
        
        System.out.print("Enter your last name: ");
        lastName= input.nextLine();
        
        System.out.println(firstName+ " "+ middleName+ " "+ lastName);
        
        /*
         * Exercise 2 Answer:
         * Technically, either works perfectly in this scenario. However, using + operator, the concat with String, is more preferable and flexible than using concat() method because the concat() can only be used for String(characters).
         */
    }
    
}
