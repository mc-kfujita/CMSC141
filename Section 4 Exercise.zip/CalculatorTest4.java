
public class CalculatorTest4 {
    public static void main(String[] args) {
        
       Calculator4 calc = new Calculator4();
       
       calc.findTotal("Person 1", 10);
       
       calc.findTotal("Person 2", 12);
       calc.findTotal("Person 3", 9);
       calc.findTotal("Person 4", 8);
       calc.findTotal("Person 5", 7);
       calc.findTotal("Person 6(Alex)", 15);
       calc.findTotal("Person 7", 11);
       calc.findTotal("Person 8", 30);
       calc.calculate(122.4, 6);
       calc.display();
    }
}