import java.util.Scanner;

public class ComputeSum {

    public static void main(String[] args) {
    	int sum= 0;
        int i=1;
    	
    	System.out.println("Please enter 10 numbers\nEnter 0 to exit.");
    	Scanner input = new Scanner(System.in);
    	int num = input.nextInt();
        
        while(num != 0) {
        	if(i<10) {
        		sum= sum+ num;
        		num= input.nextInt();
        		i++;
        		
        	}
        	
        	else {
        		break;
        	}
        	
        }
        
        System.out.println("The sum of the numbers you entered is " + sum+ ".");

    }
}