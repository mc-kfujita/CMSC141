import java.util.Scanner;

public class SumofNums {

    public static void main(String args[]) {
    	
    	/*
    	 * Can you implement a summing up sequence of 10 integers that are input by user using a do-while loop?
    	 */
    	
    	//Answer: Yes, it can. Here is the code I modified it allowing user input up to 10 times and display the total numbers of the inputs. Inputing -1 will immediately quit the while loop and display the total numbers of the inputs.
    	
        Scanner console = new Scanner(System.in);
        int sum = 0;
        System.out.print("Enter a number (-1 to quit): ");
        int number = console.nextInt();
        int i=1;

        while (number != -1 ) {
        	
        	if(i<10) {
        		sum = sum + number;     // moved to top of loop
        		System.out.print("Enter a number (-1 to quit): ");
        		number = console.nextInt();
        		i++;
        	}
        	
        	else {
        		break;
        	}
        	
        }

        System.out.println("The sum is " + sum);

    }
}
