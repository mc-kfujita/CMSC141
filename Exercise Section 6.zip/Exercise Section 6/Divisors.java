import java.util.Scanner;

public class Divisors {

    public static void main(String args[]) {
    	
    	//Creating scanner object.
         Scanner console = new Scanner(System.in);
         
        //Display the message to Let a user enter the number
        System.out.print("Enter the number :  ");
        
        //Implementing int num from the user input.
        int num = console.nextInt();
         
        //Display the template message that also consists of the user input number.
        System.out.print("Divisors of " + num+" "+ "="+" " );
        
        /*Using for loop statement to condition if there is the divisor in the user input number.
        *each loop will increment int i, and for loop will continue while i value is smaller than num; the loop will stop when i value becomes equal or greater than num value, the user input number.
        *
        *for(Implementing loop counter and its value; conditions; increments/decrements)
        *i is the loop variable.
        */
        
        //The for loop will execute if num, the user input number is grater than i value which is 1. If i value becomes equal and or greater than num, loop will not execute and the program will stop.
        for (int i = 1; i < num; i++) {
            
        	//Conditioning to find if num the user input has divisors.
        	if (num % i != 0) {
        		
        		//If num meets the if statement condition, it goes to next iteration. Otherwise it starts next loop. In this case, i is incremented by 1.
        		continue;
            }
        	
        	//When num meets the if condition, display the divisors of i and ", " and i is incremented, then goes to next loop.
            System.out.print(i + " , ");
        }
    }
}
