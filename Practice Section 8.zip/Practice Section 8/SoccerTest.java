
public class SoccerTest {
	
	//Main method
	public static void main(String[] args) {
		
		//Instantiating a league and scheduler
		SoccerLeague league= new SoccerLeague();
		SoccerScheduler scheduler= new SoccerScheduler(league);
		
		//Start testing.
		scheduler.weatherCheck();
	}

}
