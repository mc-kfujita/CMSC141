
public class SoccerTeam {
	
	//Fields
	private String teamName;
	private int winTotal, lossTotal, tieTotal, totalGoals, goalsAllowed;
	
	//Constructor
	public SoccerTeam(String teamName) {
		this.teamName= teamName;
		this.winTotal= 0;
		this.lossTotal= 0;
		this.tieTotal= 0;
		this.totalGoals= 0;
		this.goalsAllowed= 0;
	}
	
	//Getters
	public String getTeamName() {
		return teamName;
	}
	
	public int getWinTotal() {
		return winTotal;
	}
	
	public int getLossTotal() {
		return lossTotal;
	}
	
	public int getTieTotal() {
		return tieTotal;
	}
	
	public int getTotalGoals() {
		return totalGoals;
	}
	
	public int getGoalsAllowed() {
		return goalsAllowed;
	}
	
	//Setters
	public void setTeamName(String teamName) {
		this.teamName= teamName;
	}
	
	public void setWinTotal(int winTotal) {
		this.winTotal= winTotal;
	}
	
	public void setLossTotal(int lossTotal) {
		this.lossTotal= lossTotal;
	}
	
	public void setTieTotal(int tieTotal) {
		this.tieTotal= tieTotal;
	}
	
	public void setTotalGoals(int totalGoals) {
		this.totalGoals= totalGoals;
	}
	
	public void setGoalsAllowed(int goalsAllowed) {
		this.goalsAllowed= goalsAllowed;
	}
	
	//Score method
	public void scoreStat(int totalGoals, int goalsAllowed) {
		this.totalGoals += totalGoals;
		this.goalsAllowed += goalsAllowed;
		
		if(totalGoals> goalsAllowed)
			winTotal++;
		else if(totalGoals< goalsAllowed)
			lossTotal++;
		else
			tieTotal++;
	}
	
	//toString method
	public String toString() {
		return "\nTeam "+ getTeamName()+ "\nWins: "+ getWinTotal()+ ", Losses: "+ getLossTotal()+ ", Ties: "+ getTieTotal()+ "\nPoints Scored: "+ getTotalGoals()+ ", Points Allowed: "+ getGoalsAllowed();
	}

}
