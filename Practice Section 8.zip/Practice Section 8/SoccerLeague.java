import java.util.ArrayList;

public class SoccerLeague {
	
	//Fields
	private SoccerTeam[] teams;
	private ArrayList<SoccerGame> games;
	
	//Constructor
	public SoccerLeague() {
		this.teams= new SoccerTeam[] {new SoccerTeam("1"), new SoccerTeam("2"), new SoccerTeam("3"), new SoccerTeam("4")};
		this.games= new ArrayList<>();
	}
	
	//Getters
	public SoccerTeam[] getTeams() {
		return teams;
	}
	
	public ArrayList<SoccerGame> getGames() {
		return games;
	}
	
	
	//Setters
	public void setTeams(SoccerTeam[] teams) {
		this.teams= teams;
	}
	
	public void setGames(ArrayList<SoccerGame> games) {
		this.games= games;
	}
	
	//Method to open soccer games.
	public void openGame(SoccerGame game) {
		games.add(game);
	}

}
