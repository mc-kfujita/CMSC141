import java.util.Formatter;
import java.util.InputMismatchException;
import java.util.Scanner;

public class SoccerScheduler {
	
	//Fields
	private SoccerLeague league;
	private int gameStat, weatherStat;
	
	//Constructor
	public SoccerScheduler(SoccerLeague league) {
		this.league= league;
		this.gameStat= 0;
		this.weatherStat= 0;
	}
	
	//Method to schedule games when weather is above freezing point. When games are scheduled, it opens the games and generate its scores randomly.
	private void scheduleGame(double temp) {
		SoccerTeam awayTeam;
		SoccerTeam homeTeam;
		
		do {
			awayTeam= league.getTeams()[(int) (Math.random()* league.getTeams().length)];
			homeTeam= league.getTeams()[(int) (Math.random()* league.getTeams().length)];
		}
		
		while(awayTeam == homeTeam);
		
		double maxScore= temp/ 10;
		int awayTeamScore= (int) (Math.random()* (maxScore));
		int homeTeamScore= (int) (Math.random()* (maxScore));
		
		awayTeam.scoreStat(awayTeamScore, homeTeamScore);
		homeTeam.scoreStat(homeTeamScore, homeTeamScore);
		
		SoccerGame game= new SoccerGame(awayTeam, homeTeam, awayTeamScore, homeTeamScore, ++gameStat, temp);
		league.openGame(game);
		
	}
	
	//Method to calculate the necessary information and display the result based on the user input temperature and the random generated scores.
	private void displayResult() {
		System.out.println("\n\n*********Result*********\n\n\n");
		
		for(SoccerTeam team: league.getTeams()) {
			System.out.println(team);
		}
		
		double sumOfTemp= 0;
		double maxTemp= Integer.MIN_VALUE;
		
		for(SoccerGame game: league.getGames()) {
			sumOfTemp += game.getTemp();
			maxTemp= Math.max(maxTemp, game.getTemp());
			
			System.out.println(game);
		}
		
		double avgTemp= sumOfTemp/ league.getGames().size();
		
		Formatter fmtMax= new Formatter();
		Formatter fmtAvg= new Formatter();
		
		fmtMax.format("%.1f", maxTemp);
		fmtAvg.format("%.1f", avgTemp);
		
		System.out.println("\nHottest Temp: "+ fmtMax+ "\nAverage Temp: "+ fmtAvg);
	}
	
	//Method to let user input weather, if temperature in number is put and is above freezing point.
	//Keep asking user to input the temperature until freezing weather continues three times.
	//When freezing weather continues three times, the program will output the result based on the user input.
	//If user does not input a number, output him or her to input number next time then quit the program.
	//If user inputs "150", loop will stop and result will output right away.
	public void weatherCheck() {
		Scanner input= new Scanner(System.in);
		
		try {
			while(weatherStat <3) {
				System.out.print("Enter a temperature. (Enter 150 to exit the program): ");
				double temp= input.nextDouble();
				
				if(temp < 32) {
					System.out.println("Too cold to play.");
					weatherStat++;
				}
				else if(temp == 150) {
					System.out.println("Exiting the program.\nResult based on your input is below.");
					displayResult();
					break;
				}
				else {
					weatherStat= 0;
					
					for(int i=0; i<2; i++) {
						scheduleGame(temp);
					}
				}
			}
			
			System.out.println("Season is over.");
			displayResult();
		}
		
		catch(InputMismatchException e) {
			System.out.println("\nPlease only input numbers!\nExiting the program.");
		}
	}
	
	
}