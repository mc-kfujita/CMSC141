
public class SoccerGame {
	
	//Fields
	private SoccerTeam awayTeam, homeTeam;
	private int awayTeamScore, homeTeamScore, numID;
	private double temp;
	
	//Constructor
	public SoccerGame(SoccerTeam awayTeam, SoccerTeam homeTeam, int awayTeamScore, int homeTeamScore, int numID, double temp) {
		this.awayTeam= awayTeam;
		this.homeTeam= homeTeam;
		this.awayTeamScore= awayTeamScore;
		this.homeTeamScore= homeTeamScore;
		this.numID= numID;
		this.temp= temp;
	}
	
	//Getters
	public SoccerTeam getAwayTeam() {
		return awayTeam;
	}
	
	public SoccerTeam getHomeTeam() {
		return homeTeam;
	}
	
	public int getAwayTeamScore() {
		return awayTeamScore;
	}
	
	public int getHomeTeamScore() {
		return homeTeamScore;
	}

	public int getNumID() {
		return numID;
	}
	
	public double getTemp() {
		return temp;
	}
	
	//Setters
	public void setAwayTeam(SoccerTeam awayTeam) {
		this.awayTeam= awayTeam;
	}
	
	public void setHomeTeam(SoccerTeam homeTeam) {
		this.homeTeam= homeTeam;
	}
	
	public void setAwayTeamScore(int awayTeamScore) {
		this.awayTeamScore= awayTeamScore;
	}
	
	public void setHomeTeamScore(int homeTeamScore) {
		this.homeTeamScore= homeTeamScore;
	}
	
	public void setNumID(int numID) {
		this.numID= numID;
	}
	
	public void setTemp(double temp) {
		this.temp= temp;
	}
	
	//toString Method
	public String toString() {;
		return "\nGame #"+ numID+ "\nTemperature: "+ temp+ "\nAway Team: "+awayTeam.getTeamName()+ ", "+ getAwayTeamScore()+ "\nHome Team: "+homeTeam.getTeamName()+ ", "+ getHomeTeamScore();
	}

}
