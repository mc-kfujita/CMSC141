import java.util.Scanner;

public class WatchMovie {

    public static void main(String args[]) {
        System.out.print("Enter the movie ticket price \n");
        
        Scanner input= new Scanner(System.in);
        int price= input.nextInt();
        
        System.out.print("Enter the rate of the movie \n");
        double rating = input.nextInt();
        
        if(price >= 12 && rating == 5) {
            System.out.println("I'm interested in watching the movie.");
        }
        
        else {
            System.out.println("I am not interested in watching the movie.");
        }

    }
}
