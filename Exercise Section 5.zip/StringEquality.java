import java.util.Scanner;
public class StringEquality {
	
	public static void main(String[] args) {
		
		System.out.println("Enter a name: ");
		Scanner input= new Scanner(System.in);
		String name= input.nextLine();
		
		if(name.equals("Moe")) {
			System.out.println("You are the king of Rock and Roll.");
		}
		
		else {
			System.out.println("You are not the king.");

		}
		
	}
   
    
}

