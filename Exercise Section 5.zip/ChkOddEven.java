import java.util.Scanner;

public class ChkOddEven {

    public static void main(String args[]) {

        Scanner in = new Scanner(System.in);
        int num = 0;
        System.out.println("Enter a number between 1 and 10: ");
        num = in.nextInt();
        
        if(num <= 10 && num> 0) {
        	if(num%2 == 0) {
        		System.out.println("The number is even " +num);
        	}
        	
        	else {
        		System.out.println("The number is odd " +num);
        	}
        }
        
        else {
            System.out.println("Please put the number between 1 and 10.");

        }
        
    }
}
