import java.util.Scanner;

public class AgeValidity {

    public static void main(String[] args) {
    	System.out.println("Enter your age: ");
    	Scanner input= new Scanner(System.in);
    	int age= input.nextInt();
    			
    	boolean drivingUnderAge= false;
    	
    	if(18 >= age) {
    		drivingUnderAge= true;
    		System.out.println("Driving under age: "+ drivingUnderAge);
    		System.out.println("You are not legal age to drive.");
    	}
    	
    	else {
    		System.out.println("Driving under age: "+ drivingUnderAge);
    		System.out.println("You are legal age to drive.");
    	}
    
    }
}
