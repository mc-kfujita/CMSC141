import java.util.Scanner;

public class ComputeAvg {

    public static void main(String args[]) {
        int scores[]= new int[] {70, 80, 90, 95, 100};
        double total= 0.0;
        double avg= 0.0;
        
        for(int i=0; i<scores.length; i++) {
        	System.out.print(scores[i]+ " ");
        	
            total += scores[i];
            
            if(i == 4)
                avg= total/ scores.length;

        }
        
    	System.out.print("\nAverage socre of "+ scores.length+ " exams is "+ avg+ ".");
    }

}
