
public class BoundaryTesting {

    public static void main(String args[]) {
        int CALENDAR_START = 1582;
        int year = 1582;
        int month = 2;
        // validate input 
        int[] arrYear= new int[5];
        int[] arrMonth= new int[5];
        
        arrYear[0]= year;
        arrYear[1]= year+1;
        arrYear[2]= year+1;
        arrYear[3]= year+1;
        arrYear[4]= year+1;
        arrMonth[0]= month;
        arrMonth[1]= month-2;
        arrMonth[2]= month+11;
        arrMonth[3]= month-1;
        arrMonth[4]= month+10;
        
        System.out.println("Year\tMonth");       
        
        if ((arrYear[0] >= CALENDAR_START || arrYear[1] >= CALENDAR_START || arrYear[2] >= CALENDAR_START || arrYear[3] >= CALENDAR_START || arrYear[4]>= CALENDAR_START ||
           (arrMonth[0] <= 2) || (arrMonth[1] <= 2) || (arrMonth[2] <= 2) || (arrMonth[3] <= 2) || (arrMonth[4] <= 2) ||
           (arrMonth[0] >= 12) || (arrMonth[1] >= 12) || (arrMonth[2] >= 12) || (arrMonth[3] >= 12) || (arrMonth[4] >= 12))) {
        	
        	for(int i=0; i<arrYear.length && i< arrMonth.length ;i++) {
        		System.out.print(arrYear[i]+ "\t"+arrMonth[i]+"\n");
        		
        	}
        }
    }
}