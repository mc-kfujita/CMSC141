public class ExceptionEx1 {

    public static void main(String args[]) {

        int[] nums = {3, 2, 6, 1};
        badUse(nums);
    }

    public static void badUse(int[] vals) {
        int total = 0;

        for (int i = 0; i < vals.length; i++) {
//            int index = vals[i]; //Commenting out this line because it is unnecessary.
            total += vals[i]; //Fix vals[index] to vals[i]. Now badUse is goodUse.
        }
         System.out.println(total);
    }
}

/*
* Question: Is it good practice to handle the exception for this program?
* Answer: It is always important to debug the codes others write for reviewing purpose.
*/