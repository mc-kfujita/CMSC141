import java.util.ArrayList;

public class ArrayListEx1 {

    public static void main(String[] args) {
    	ArrayList<String> students= new ArrayList<String>();
    	
    	students.add(0, "Amy");
    	students.add(1, "Bob");
    	students.add(2, "Cindy");
    	students.add(3, "David");
    	
    	for(String str: students) {
    		System.out.print(str+ " ");
    	}
    	
    	System.out.print("\nThe ArrayList size is "+ students.size()+ ".\n");
    	
    	students.set(0, "Nick");
    	students.set(1, "Mike");
    	students.remove(3);
    	
    	for(String str: students) {
    		System.out.print(str+ " ");
    	}
    	
    	System.out.print("\nThe current ArrayList size is "+ students.size()+ ".");
    }
    
}
