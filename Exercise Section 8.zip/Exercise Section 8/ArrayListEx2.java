import java.util.ArrayList;
import java.util.ListIterator;

public class ArrayListEx2 {
    public static void main(String args[]) {
    	ArrayList<Integer> numbers= new ArrayList<Integer>();
    	
    	numbers.add(0, 1);
    	numbers.add(1, 2);
    	numbers.add(2, 3);
    	numbers.add(3, 4);
    	numbers.add(4, 5);
    	
    	ListIterator<Integer> itr= numbers.listIterator();
    	
    	while(itr.hasNext()) {
    		System.out.print(itr.next()+ " ");
    		}
    	
    	for(int i=0; i<numbers.size(); i++) {
    		if(numbers.get(i)%2 == 0) {
    			numbers.remove(i);
    		}  	
    	}
    	
		System.out.print("\n"+ numbers);
    }
}
